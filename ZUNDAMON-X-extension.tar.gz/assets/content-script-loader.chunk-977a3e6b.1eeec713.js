(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-977a3e6b.js")
    );
  })().catch(console.error);

})();
